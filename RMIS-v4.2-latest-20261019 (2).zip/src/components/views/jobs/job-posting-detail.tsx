"use client";

// ============================================================================
// RMIS — Job posting DETAIL mode (#/job-opportunities?job=<id>).
// Task 13 — the user pinned the EXACT reference look (Workze-style posting):
// a plain typographic MAIN column — oversized bold title, employer line,
// an icon meta row (place · position type), a hairline rule, then the KEPT
// "Job Description | Job Detail" tab navs (user asked to maintain these)
// over simple bold section headings (Overview / Responsibilities /
// Qualifications; Detail tab = MQR divider rows + Compensation + Timeline)
// — and a right ASIDE of two white hairline cards: the summary card (place
// row, application note, salary headline + caption, divider, plain icon
// rows — Item No. / Position Type / Vacancies / Salary Grade / Application
// Deadline / Posted, the reference's row anatomy) with the session-aware
// dark-ink CTA — Apply for this job / Re-apply / Sign in to Apply (locked
// once the deadline passes) or the disabled Application Submitted + Cancel
// Application behind its AlertDialog (spec §7.7) — plus the small agency
// card (tile · DOST-MIRDC · division · one-line blurb). A compact lg:hidden
// CTA under the header keeps the apply action above the phone fold (the
// reference's aside lands below the content there). NOT a modal — a full
// page. Router contract unchanged: #/job-opportunities (no job param) = the
// Job Opportunities explorer; #/job-opportunities?job=<id> = THIS page — the
// home quick-view's "Read full description" destination. Data: GET
// /api/jobs?limit=200 (mount + 30s silent poll + focus refetch) so the
// Applied state stays truthful; closed postings still render (locked CTA),
// unknown ids get the "Position not found" state. Works for anonymous
// visitors — the apply gate (useApplyFlow) routes them to sign-in. No
// email-sender files touched.
// ============================================================================

import { useCallback, useEffect, useMemo, useRef, useState, type ComponentType } from "react";
import {
  ArrowLeft,
  Briefcase,
  CalendarClock,
  Check,
  Clock,
  Coins,
  FileText,
  MapPin,
  Search,
  Users,
} from "lucide-react";
import { toast } from "@/lib/toast";
import { useApplyFlow } from "@/components/apply/apply-dialogs";
import { useSession } from "@/components/session-provider";
import { ghostBadBtn } from "@/components/ui/buttons";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { apiFetch, deadlineState, formatCurrency, formatDate, humanize } from "@/lib/client";
import { isActiveApplicationStatus } from "@/lib/status";
import { divisionFullName } from "@/lib/constants";
import { navigate, useHashRoute, type JobWire } from "@/lib/router";
import { EmptyState, ErrorCard } from "@/components/ui/shell";
import { Alert, AlertContent, AlertDescription, AlertIcon, AlertTitle } from "@/components/motion/alert";
import { Skeleton } from "@/components/ui/skeleton";

// ── Helpers ─────────────────────────────────────────────────────────────────

function sgLabel(grade: string | null | undefined, step: string | null | undefined): string {
  if (!grade) return "-";
  return step ? `SG${grade}/${step}` : `SG${grade}`;
}

function RichOrPlain({ html, text }: { html?: string | null; text?: string | null }) {
  if (html && html.trim()) {
    return (
      <div
        className="rich-text text-sm leading-relaxed text-stone"
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }
  if (text && text.trim()) {
    return <p className="whitespace-pre-line text-sm leading-relaxed text-stone">{text}</p>;
  }
  return <p className="text-sm text-stone">Not provided.</p>;
}

/* The reference's dark-ink CTA (near-black navy, white ink, 12px radius) —
   a FIXED ink literal on purpose: the button must stay the reference's dark
   slab on both themes (bg-ink would flip light at night); the night ring
   keeps its edge readable on the raised card. */
const INK_CTA =
  "focus-ring inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#0e1c26] text-sm font-medium text-white transition-colors hover:bg-[#1c313c] disabled:pointer-events-none disabled:opacity-50 dark:ring-1 dark:ring-white/10";

// ── Main · typographic header (reference: title / employer / meta row) ──────

function PostingHeader({
  job,
  signedIn,
  onApply,
}: {
  job: JobWire;
  signedIn: boolean;
  onApply: (job: JobWire) => void;
}) {
  const pos = job.position;
  const dl = deadlineState(job.deadlineDate);
  const applied = (job.applications ?? []).some((a) => isActiveApplicationStatus(a.status));
  const priorAttempt = !applied && (job.applications?.length ?? 0) > 0;
  const ctaLabel = applied
    ? "Application Submitted"
    : dl.overdue
      ? "Applications Closed"
      : priorAttempt
        ? "Re-apply"
        : signedIn
          ? "Apply for this job"
          : "Sign in to Apply";

  return (
    <header aria-label="Position header">
      <h1 className="text-3xl font-bold leading-tight tracking-tight text-ink sm:text-4xl">
        {humanize(job.title)}
      </h1>
      <p className="mt-2 text-[15px] leading-snug text-stone">
        {pos?.division ? `DOST-MIRDC · ${divisionFullName(pos.division)}` : "DOST-MIRDC"}
      </p>

      {/* Meta row — icon pairs split by the reference's middot */}
      <div className="mt-4 flex flex-wrap items-center gap-x-2.5 gap-y-1.5 text-sm text-body-gray">
        <span className="flex min-w-0 items-center gap-1.5">
          <MapPin className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span className="truncate">
            {pos?.placeOfAssignment || (pos?.division ? divisionFullName(pos.division) : "Philippines")}
          </span>
        </span>
        <span aria-hidden="true">·</span>
        <span className="flex items-center gap-1.5">
          <Briefcase className="h-4 w-4 shrink-0" aria-hidden="true" />
          {job.positionType ? humanize(job.positionType) : "-"}
        </span>
      </div>

      {/* Phones only — the aside (with the full CTA + cancel flow) stacks
          below the posting on small screens, so the apply action still sits
          above the fold; the reference layout itself starts at lg. */}
      <div className="mt-5 lg:hidden">
        <button
          type="button"
          onClick={() => onApply(job)}
          disabled={dl.overdue || applied}
          className={`${INK_CTA} w-full`}
        >
          {applied && <Check className="h-4 w-4" aria-hidden="true" />}
          {ctaLabel}
        </button>
      </div>
    </header>
  );
}

// ── Main · "Job Description | Job Detail" tabs (kept per user request) ──────

function DetailTabs({ job }: { job: JobWire }) {
  const pos = job.position;
  const dl = deadlineState(job.deadlineDate);
  const [tab, setTab] = useState<"description" | "detail">("description");

  const mqrRows: [string, string | null | undefined][] = [
    ["Education", pos?.cscEducation],
    ["Work Experience", pos?.cscWorkExperience],
    ["Training", pos?.cscTraining],
    ["Eligibility", pos?.cscEligibilityGroup],
    ["License / Certification", pos?.license],
  ];
  const visibleMqr = mqrRows.filter(([, v]) => v && !/^(n\/?a|none|na)\.?$/i.test(v.trim()));

  const tabs = [
    { id: "description", label: "Job Description" },
    { id: "detail", label: "Job Detail" },
  ] as const;

  return (
    <section aria-label="Position information" className="mt-7">
      <div
        role="tablist"
        aria-label="Position information sections"
        className="flex gap-6 border-b border-border"
      >
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            id={`job-tab-${t.id}`}
            aria-selected={tab === t.id}
            aria-controls={`job-panel-${t.id}`}
            onClick={() => setTab(t.id)}
            className={`focus-ring relative min-h-[48px] px-1 text-sm transition-colors ${
              tab === t.id
                ? "font-medium text-ink after:bg-primary"
                : "text-body-gray hover:text-ink after:bg-transparent"
            } after:absolute after:inset-x-0 after:bottom-0 after:h-0.5 after:rounded-full`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Description tab — the reference's Overview / Responsibilities /
          Qualifications section stack */}
      <div
        role="tabpanel"
        id="job-panel-description"
        aria-labelledby="job-tab-description"
        hidden={tab !== "description"}
        className="space-y-7 pt-6"
      >
        <div>
          <h2 className="text-base font-bold text-ink">Overview</h2>
          <div className="mt-2.5">
            <RichOrPlain html={job.briefDescriptionHtml} text={job.briefDescription} />
          </div>
        </div>
        <div>
          <h2 className="text-base font-bold text-ink">Responsibilities</h2>
          <div className="mt-2.5">
            <RichOrPlain html={job.dutiesHtml} text={job.dutiesResponsibilities} />
          </div>
        </div>
        {(job.otherQualificationsHtml?.trim() || job.otherQualifications?.trim()) && (
          <div>
            <h2 className="text-base font-bold text-ink">Qualifications</h2>
            <div className="mt-2.5">
              <RichOrPlain html={job.otherQualificationsHtml} text={job.otherQualifications} />
            </div>
          </div>
        )}
      </div>

      {/* Detail tab — MQR divider rows, compensation, timeline tiles */}
      <div
        role="tabpanel"
        id="job-panel-detail"
        aria-labelledby="job-tab-detail"
        hidden={tab !== "detail"}
        className="space-y-7 pt-6"
      >
        <div>
          <h2 className="text-base font-bold text-ink">Minimum Qualification Requirements</h2>
          <div className="mt-1">
            {visibleMqr.length > 0 ? (
              visibleMqr.map(([label, value], i) => (
                <div
                  key={label}
                  className={`grid gap-1 py-3.5 sm:grid-cols-[200px_1fr] sm:gap-4 ${
                    i > 0 ? "border-t border-border" : ""
                  }`}
                >
                  <p className="text-sm font-medium text-ink">{label}</p>
                  <p className="text-sm leading-relaxed text-stone">{value}</p>
                </div>
              ))
            ) : (
              <p className="py-3.5 text-sm text-stone">
                No minimum requirements published for this position.
              </p>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-base font-bold text-ink">Compensation Package</h2>
          <div className="mt-2.5">
            <RichOrPlain html={job.compensationHtml} text={job.compensationPackage} />
          </div>
        </div>

        <div>
          <h2 className="text-base font-bold text-ink">Timeline</h2>
          <div className="mt-2.5 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-cloud/60 p-4">
              <p className="text-xs text-body-gray">Published</p>
              <p className="num mt-0.5 text-sm text-ink">{formatDate(job.publishDate ?? job.publishedAt)}</p>
            </div>
            <div className="rounded-xl bg-cloud/60 p-4">
              <p className="text-xs text-body-gray">Deadline</p>
              <p
                className={`num mt-0.5 flex items-center gap-1.5 text-sm ${
                  dl.overdue ? "text-[var(--bad)]" : "text-ink"
                }`}
              >
                {/* Hue never carries state alone — the overdue date gets the
                    same Clock glyph the recruitment table pairs with it. */}
                {dl.overdue && <Clock className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />}
                {formatDate(job.deadlineDate)}
                {job.deadlineDate ? ` · ${dl.label}` : ""}
              </p>
            </div>
            <div className="rounded-xl bg-cloud/60 p-4">
              <p className="text-xs text-body-gray">Processing</p>
              <p className="num mt-0.5 text-sm text-ink">{formatDate(job.processingDate)}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Aside · summary card (reference: place / note / salary / rows / CTA) ────

function SummaryCard({
  job,
  signedIn,
  onApply,
  onCancel,
  cancelling,
}: {
  job: JobWire;
  signedIn: boolean;
  onApply: (job: JobWire) => void;
  onCancel: () => void;
  cancelling: boolean;
}) {
  const pos = job.position;
  const dl = deadlineState(job.deadlineDate);
  // MOM 2026-10-13 — re-application: an active application shows the applied
  // state + Cancel; a rejected/withdrawn history shows the re-apply path.
  const applied = (job.applications ?? []).some((a) => isActiveApplicationStatus(a.status));
  const priorAttempt = !applied && (job.applications?.length ?? 0) > 0;

  const rows: { icon: ComponentType<{ className?: string }>; value: string; caption: string; overdue?: boolean }[] = [
    { icon: FileText, value: pos?.itemNumber || "-", caption: "Item No." },
    { icon: Briefcase, value: job.positionType ? humanize(job.positionType) : "-", caption: "Position Type" },
    {
      icon: Users,
      value: job.numberOfVacancy == null ? "-" : String(job.numberOfVacancy),
      caption: "Vacancies",
    },
    { icon: Coins, value: sgLabel(pos?.salaryGrade, pos?.salaryStep), caption: "Salary Grade" },
    {
      icon: CalendarClock,
      value: job.deadlineDate ? formatDate(job.deadlineDate) : "Open until filled",
      caption: dl.overdue ? "Deadline passed" : "Application Deadline",
      overdue: dl.overdue,
    },
    { icon: Clock, value: formatDate(job.publishDate ?? job.publishedAt), caption: "Posted" },
  ];

  return (
    <div className="dlg-card-plain border border-border p-6" aria-label="Position summary">
      <div className="flex items-center gap-2.5">
        <MapPin className="h-4 w-4 shrink-0 text-body-gray" aria-hidden="true" />
        <p className="truncate text-sm font-medium text-ink">
          {pos?.placeOfAssignment || (pos?.division ? divisionFullName(pos.division) : "-")}
        </p>
      </div>
      <p className="mt-2.5 text-sm leading-relaxed text-stone">
        Please submit your application for this job post on or before the deadline.
      </p>

      <div className="mt-5 border-t border-border pt-5">
        <p className="num text-3xl font-bold leading-none text-ink">
          {pos?.salaryAmount != null
            ? formatCurrency(pos.salaryAmount)
            : pos?.salaryGrade
              ? `SG${pos.salaryGrade}`
              : "-"}
        </p>
        <p className="mt-1.5 text-xs text-body-gray">Monthly Salary</p>
      </div>

      <ul className="mt-5 space-y-3.5 border-t border-border pt-5">
        {rows.map(({ icon: Icon, value, caption, overdue }) => (
          <li key={caption} className="flex items-center gap-3">
            <Icon
              className={`h-4 w-4 shrink-0 ${overdue ? "text-[var(--bad)]" : "text-body-gray"}`}
              aria-hidden="true"
            />
            <span className="min-w-0">
              <span
                className={`num block truncate text-sm font-medium ${
                  overdue ? "text-[var(--bad)]" : "text-ink"
                }`}
                title={value}
              >
                {value}
              </span>
              <span className="block text-xs text-body-gray">{caption}</span>
            </span>
          </li>
        ))}
      </ul>

      <div className="mt-5">
        <Alert variant="success" open={applied} className={applied ? "mb-3" : undefined}>
          <AlertIcon>
            <Check />
          </AlertIcon>
          <AlertContent>
            <AlertTitle>Successfully Applied</AlertTitle>
            <AlertDescription>Your application is in the pipeline.</AlertDescription>
          </AlertContent>
        </Alert>
        {/* MOM 2026-10-13 — the applicant may re-apply after a rejection. */}
        <Alert variant="warning" open={priorAttempt} className={priorAttempt ? "mb-3" : undefined}>
          <AlertIcon>
            <Clock />
          </AlertIcon>
          <AlertContent>
            <AlertTitle>Previous application not shortlisted</AlertTitle>
            <AlertDescription>You may re-apply to this posting while it remains open.</AlertDescription>
          </AlertContent>
        </Alert>

        {applied ? (
          <>
            <button type="button" disabled className={`${INK_CTA} w-full`}>
              <Check className="h-4 w-4" aria-hidden="true" />
              Application Submitted
            </button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <button
                  className="focus-ring mt-2 min-h-[44px] w-full rounded-xs text-sm font-medium text-body-gray underline-offset-2 hover:text-ink hover:underline disabled:pointer-events-none disabled:opacity-50"
                  disabled={cancelling}
                >
                  Cancel Application
                </button>
              </AlertDialogTrigger>
              <AlertDialogContent className="dlg-card-plain">
                <AlertDialogHeader>
                  <AlertDialogTitle className="font-display text-2xl text-ink">
                    Cancel this application?
                  </AlertDialogTitle>
                  <AlertDialogDescription className="text-sm text-body-gray">
                    Your application for {humanize(job.title)} will be withdrawn. You can apply
                    again while the position is open.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="dlg-ghost min-h-[44px] px-6 text-sm">
                    Keep application
                  </AlertDialogCancel>
                  <AlertDialogAction onClick={onCancel} className={`${ghostBadBtn} px-6`}>
                    Cancel application
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={() => onApply(job)}
              disabled={dl.overdue}
              className={`${INK_CTA} w-full`}
            >
              {dl.overdue ? "Applications Closed" : priorAttempt ? "Re-apply" : signedIn ? "Apply for this job" : "Sign in to Apply"}
            </button>
            {dl.overdue && (
              <p className="mt-2 text-center text-xs text-stone">
                The deadline for this position has passed.
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}

// ── Aside · agency mini-card (reference: tile / name / divider / blurb) ─────

function CompanyCard({ job }: { job: JobWire }) {
  const pos = job.position;
  return (
    <div className="dlg-card-plain border border-border p-5" aria-label="About the agency">
      <div className="flex items-center gap-3">
        <div
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-cloud text-lg font-bold text-ink"
          aria-hidden="true"
        >
          M
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-ink">DOST-MIRDC</p>
          <p className="truncate text-xs text-body-gray">
            {pos?.division ? divisionFullName(pos.division) : "Department of Science and Technology"}
          </p>
        </div>
      </div>
      <p className="mt-3.5 border-t border-border pt-3.5 text-xs leading-relaxed text-stone">
        {pos?.division
          ? `An agency of the DOST hiring through its ${divisionFullName(pos.division)}.`
          : "An agency of the DOST driving the Philippine metals and engineering industry through research and development, technology transfer, testing, and training services."}
      </p>
    </div>
  );
}

// ── View ────────────────────────────────────────────────────────────────────

export default function JobPostingDetail() {
  const route = useHashRoute();
  const detailParam = route.params.job ?? null;
  const { user } = useSession();

  // Shell contract (previous-RMIS responsive fix 3-a): PublicShell's <main>
  // is a bare flex column (no padding), so the anonymous page paints its own
  // 1600px public-grid container + gutters; AppShell's <main> already
  // carries the workspace container, so signed-in views stay a plain w-full.
  const shellPad = user
    ? "w-full"
    : "mx-auto w-full max-w-[1600px] px-4 py-6 sm:px-6 sm:py-8 lg:px-8";

  const [jobs, setJobs] = useState<JobWire[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const lastJson = useRef("");
  const [cancelling, setCancelling] = useState(false);
  const { requestApply, dialogs } = useApplyFlow();

  const load = useCallback(async (silent: boolean) => {
    try {
      const data = await apiFetch<JobWire[]>("/api/jobs?limit=200");
      const json = JSON.stringify(data);
      if (!silent || json !== lastJson.current) {
        lastJson.current = json;
        setJobs(data);
      }
      setError(null);
    } catch (e) {
      if (!silent) setError(e instanceof Error ? e.message : "Failed to load the position");
    }
  }, []);

  // Mount + 30s silent poll + refetch on focus — keeps the Applied state and
  // the deadline lock truthful while the page is open.
  useEffect(() => {
    void load(false);
    const timer = setInterval(() => {
      if (!document.hidden) void load(true);
    }, 30_000);
    const onFocus = () => void load(true);
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", onFocus);
    };
  }, [load]);

  // Cancel application (only while an ACTIVE application exists — spec §7.7).
  const appliedId = useMemo(() => {
    const detail = detailParam ? (jobs ?? []).find((j) => j.id === Number(detailParam)) : null;
    return detail?.applications?.find((a) => isActiveApplicationStatus(a.status))?.id ?? null;
  }, [detailParam, jobs]);

  const cancelApplication = useCallback(async () => {
    if (appliedId == null) return;
    setCancelling(true);
    try {
      await apiFetch(`/api/applications/${appliedId}`, { method: "DELETE" });
      toast.success("Application cancelled", {
        description: "Your application was withdrawn. You can apply again while the position is open.",
      });
      await load(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not cancel the application");
    } finally {
      setCancelling(false);
    }
  }, [appliedId, load]);

  const applyTo = useCallback(
    (job: JobWire) => {
      requestApply(job);
    },
    [requestApply]
  );

  // ── Detail mode ───────────────────────────────────────────────────────────
  if (!detailParam || !/^\d+$/.test(detailParam)) return null;

  const detailId = Number(detailParam);
  const detail = jobs?.find((j) => j.id === detailId) ?? null;

  return (
    <div className={shellPad}>
      <button
        onClick={() => navigate("job-opportunities")}
        className="focus-ring mb-5 flex min-h-[44px] items-center gap-2 rounded-xs text-sm text-body-gray hover:text-ink"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        Back to Job Opportunities
      </button>

      {jobs === null && error === null ? (
        <div className="grid grid-cols-1 items-start gap-8 lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-10">
          <div>
            <div className="space-y-3">
              <Skeleton className="h-9 w-3/4 max-w-sm" />
              <Skeleton className="h-4 w-52" />
              <Skeleton className="h-4 w-64" />
            </div>
            <div className="mt-7 space-y-3 border-t border-border pt-6">
              <Skeleton className="h-4 w-28" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          </div>
          <div className="space-y-6">
            <div className="dlg-card-plain space-y-4 border border-border p-6">
              <Skeleton className="h-4 w-40" />
              <Skeleton className="h-3 w-full" />
              <Skeleton className="h-3 w-3/4" />
              <Skeleton className="h-px w-full" />
              <Skeleton className="h-8 w-36" />
              <Skeleton className="h-px w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-12 w-full rounded-xl" />
            </div>
            <div className="dlg-card-plain space-y-3 border border-border p-5">
              <div className="flex items-center gap-3">
                <Skeleton className="h-11 w-11 rounded-xl" />
                <div className="space-y-1.5">
                  <Skeleton className="h-3.5 w-28" />
                  <Skeleton className="h-3 w-40" />
                </div>
              </div>
              <Skeleton className="h-3 w-full" />
            </div>
          </div>
        </div>
      ) : error !== null ? (
        <ErrorCard description={error} onRetry={() => void load(false)} />
      ) : detail === null ? (
        <div className="dlg-card">
          <EmptyState
            icon={Search}
            title="Position not found"
            description="This position may have closed or is no longer published."
            action={
              <button onClick={() => navigate("job-opportunities")} className={`${INK_CTA} px-7`}>
                Back to Job Opportunities
              </button>
            }
          />
        </div>
      ) : (
        // The EXACT reference anatomy: plain typographic main column (no
        // card) + a 340px sticky aside of two hairline cards. The MAIN
        // column is first in the DOM so phones read the posting first; the
        // header's lg:hidden CTA keeps the apply action above their fold.
        <div className="grid grid-cols-1 items-start gap-8 lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-10">
          <div className="min-w-0">
            <PostingHeader job={detail} signedIn={!!user} onApply={applyTo} />
            <DetailTabs job={detail} />
          </div>
          {/* Session-aware sticky offset: the public SiteHeader is sticky
              h-16, the signed-in shell has no sticky chrome at lg+. */}
          <aside aria-label="Position summary" className={`space-y-6 lg:sticky ${user ? "lg:top-6" : "lg:top-20"}`}>
            <SummaryCard
              job={detail}
              signedIn={!!user}
              onApply={applyTo}
              onCancel={() => void cancelApplication()}
              cancelling={cancelling}
            />
            <CompanyCard job={detail} />
          </aside>
        </div>
      )}

      {dialogs}
    </div>
  );
}
